CREATE FUNCTION set_creator_as_member_admin_channel () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    INSERT INTO subscribe_table
      VALUES (NEW.creator_tel_number, NEW.channel_id, TRUE);
    RETURN NULL;
  END;
  
$$
