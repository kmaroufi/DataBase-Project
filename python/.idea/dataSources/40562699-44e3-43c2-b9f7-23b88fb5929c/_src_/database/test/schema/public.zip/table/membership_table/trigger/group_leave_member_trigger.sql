CREATE TRIGGER group_leave_member_trigger
AFTER DELETE ON membership_table
FOR EACH ROW EXECUTE PROCEDURE dec_group_member_count()