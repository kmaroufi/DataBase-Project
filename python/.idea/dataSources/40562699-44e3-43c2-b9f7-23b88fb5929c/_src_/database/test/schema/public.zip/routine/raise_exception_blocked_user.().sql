CREATE FUNCTION raise_exception_blocked_user () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    IF (exists(
        SELECT * FROM blocked_contacts_table
        WHERE tel_number = NEW.receiver_tel_number AND contact_tel_number = NEW.sender_tel_number))
      THEN
      RAISE EXCEPTION 'This user is blocked!';
    END IF;
    RETURN NEW;
  END;
  
$$
