CREATE VIEW group_messages_view AS
SELECT group_sends_table.group_id,
    user_profile_view.tel_number,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.profile_image,
    group_sends_table.creator_tel_number,
    group_sends_table.message_id,
    message_table.message_text AS text,
    message_table.media_address,
    group_sends_table.send_time
   FROM ((user_profile_view
     JOIN group_sends_table USING (tel_number))
     JOIN message_table USING (creator_tel_number, message_id))