CREATE VIEW channel_creator_view AS
SELECT channel_table.channel_id,
    channel_table.creator_tel_number,
    user_profile_view.user_name,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image
   FROM (channel_table
     JOIN user_profile_view ON (((channel_table.creator_tel_number)::text = (user_profile_view.tel_number)::text)))