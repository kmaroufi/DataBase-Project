CREATE FUNCTION dec_channel_subscribe_count () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    UPDATE channel_table
      SET member_count = member_count + 1
      WHERE channel_table.channel_id = OLD.channel_id;
    RETURN NULL;
  END;
  
$$
