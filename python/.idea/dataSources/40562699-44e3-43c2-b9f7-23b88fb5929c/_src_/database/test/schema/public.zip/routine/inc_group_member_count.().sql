CREATE FUNCTION inc_group_member_count () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    UPDATE group_table
      SET member_count = member_count + 1
      WHERE group_table.group_id = NEW.group_id;
    RETURN NULL;
  END;
  
$$
