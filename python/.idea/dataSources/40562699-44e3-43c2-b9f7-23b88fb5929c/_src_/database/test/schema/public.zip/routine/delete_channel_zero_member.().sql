CREATE FUNCTION delete_channel_zero_member () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    DELETE FROM channel_table AS ct
      WHERE ct.channel_id = NEW.channel_id;
    RETURN NULL;
  END;
  
$$
