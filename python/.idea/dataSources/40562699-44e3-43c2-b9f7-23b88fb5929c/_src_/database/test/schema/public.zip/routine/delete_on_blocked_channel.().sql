CREATE FUNCTION delete_on_blocked_channel () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    DELETE FROM subscribe_table AS st
      WHERE st.channel_id = NEW.channel_id AND st.tel_number = NEW.tel_number;
    RETURN NULL;
  END;
  
$$
