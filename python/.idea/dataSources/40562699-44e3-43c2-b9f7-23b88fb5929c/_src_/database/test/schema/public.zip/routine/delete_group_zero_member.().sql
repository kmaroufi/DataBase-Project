CREATE FUNCTION delete_group_zero_member () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    DELETE FROM group_table AS gt
      WHERE gt.group_id = NEW.group_id;
    RETURN NULL;
  END;
  
$$
