CREATE FUNCTION self_seen_sender_channel () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    INSERT INTO channel_seen_table
      VALUES (NEW.tel_number, NEW.channel_id, NEW.creator_tel_number, NEW.message_id, NEW.send_time, NEW.tel_number);
    RETURN NULL;
  END;
  
$$
