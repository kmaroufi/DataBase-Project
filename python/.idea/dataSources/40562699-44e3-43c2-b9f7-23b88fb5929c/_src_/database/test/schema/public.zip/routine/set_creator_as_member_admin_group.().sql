CREATE FUNCTION set_creator_as_member_admin_group () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    INSERT INTO membership_table
      VALUES (NEW.creator_tel_number, NEW.group_id, TRUE);
    RETURN NULL;
  END;
  
$$
