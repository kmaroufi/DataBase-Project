CREATE TRIGGER user_blocked_send_trigger
BEFORE INSERT ON chat_table
FOR EACH ROW EXECUTE PROCEDURE raise_exception_blocked_user()