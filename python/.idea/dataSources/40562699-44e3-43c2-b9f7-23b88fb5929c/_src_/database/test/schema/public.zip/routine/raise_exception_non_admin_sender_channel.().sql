CREATE FUNCTION raise_exception_non_admin_sender_channel () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    IF (NOT exists(
        SELECT * FROM subscribe_table
        WHERE tel_number = NEW.tel_number AND channel_id = NEW.channel_id AND is_admin = TRUE))
      THEN
      RAISE EXCEPTION 'This user is not admin of channel!';
    END IF;
    RETURN NEW;
  END;
  
$$
