CREATE VIEW channel_blocked_view AS
SELECT channel_blocked_users_table.channel_id,
    channel_blocked_users_table.tel_number,
    user_profile_view.user_name,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image
   FROM (channel_blocked_users_table
     JOIN user_profile_view USING (tel_number))