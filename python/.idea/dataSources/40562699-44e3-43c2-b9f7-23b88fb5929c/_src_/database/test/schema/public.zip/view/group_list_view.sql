CREATE VIEW group_list_view AS
SELECT membership_table.tel_number,
    membership_table.group_id,
    group_table.name,
    group_profile_table.image_address
   FROM ((membership_table
     JOIN group_table USING (group_id))
     JOIN group_profile_table USING (group_id))
  WHERE ((group_profile_table.date)::timestamp without time zone >= ALL ( SELECT gpt.date
           FROM group_profile_table gpt
          WHERE ((group_profile_table.group_id)::integer = (gpt.group_id)::integer)))