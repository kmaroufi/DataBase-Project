CREATE VIEW group_creator_view AS
SELECT group_table.group_id,
    group_table.creator_tel_number,
    user_profile_view.user_name,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image
   FROM (group_table
     JOIN user_profile_view ON (((group_table.creator_tel_number)::text = (user_profile_view.tel_number)::text)))