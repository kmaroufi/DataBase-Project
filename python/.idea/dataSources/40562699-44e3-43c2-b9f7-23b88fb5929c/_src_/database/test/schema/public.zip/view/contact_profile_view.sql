CREATE VIEW contact_profile_view AS
SELECT contacts_table.tel_number,
    contacts_table.contact_tel_number,
    contacts_table.contact_name,
    user_profile_view.user_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image
   FROM (contacts_table
     JOIN user_profile_view ON (((contacts_table.contact_tel_number)::text = (user_profile_view.tel_number)::text)))