CREATE FUNCTION delete_on_blocked_group () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    DELETE FROM membership_table AS mt
      WHERE mt.group_id = NEW.group_id AND mt.tel_number = NEW.tel_number;
    RETURN NULL;
  END;
  
$$
