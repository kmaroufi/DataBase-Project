CREATE FUNCTION raise_exception_blocked_user_channel () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    IF (exists(
        SELECT * FROM channel_blocked_users_table
        WHERE tel_number = NEW.tel_number AND channel_id = NEW.channel_id))
      THEN
      RAISE EXCEPTION 'This user is blocked!';
    END IF;
    RETURN NEW;
  END;
  
$$
