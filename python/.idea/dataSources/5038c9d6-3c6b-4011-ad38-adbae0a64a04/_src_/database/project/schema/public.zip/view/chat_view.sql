CREATE VIEW chat_view AS
SELECT chat_table.sender_tel_number,
    chat_table.receiver_tel_number,
    message_table.creator_tel_number,
    message_table.message_id,
    chat_table.send_time,
    chat_table.seen,
    message_table.message_text AS text,
    message_table.media_address
   FROM (chat_table
     JOIN message_table USING (creator_tel_number, message_id))