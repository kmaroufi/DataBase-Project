CREATE TRIGGER channel_add_subscribe_trigger
AFTER INSERT ON subscribe_table
FOR EACH ROW EXECUTE PROCEDURE inc_channel_subscribe_count()