CREATE TRIGGER delete_group_zero_member_trigger
AFTER UPDATE OF member_count
  ON group_table
FOR EACH ROW WHEN (((new.member_count) :: BIGINT = 0)) EXECUTE PROCEDURE delete_group_zero_member()