CREATE VIEW channel_list_view AS
SELECT subscribe_table.tel_number,
    channel_table.channel_id,
    channel_table.name,
    channel_profile_table.image_address
   FROM ((subscribe_table
     JOIN channel_table USING (channel_id))
     LEFT JOIN channel_profile_table ON (((channel_table.channel_id)::text = (channel_profile_table.channel_id)::text)))
  WHERE ((channel_profile_table.date)::timestamp without time zone >= ALL ( SELECT cpt.date
           FROM channel_profile_table cpt
          WHERE ((channel_profile_table.channel_id)::text = (cpt.channel_id)::text)))