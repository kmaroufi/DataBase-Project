CREATE VIEW group_members_view AS
SELECT membership_table.group_id,
    membership_table.tel_number,
    user_profile_view.user_name,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image,
    membership_table.is_admin
   FROM (membership_table
     JOIN user_profile_view USING (tel_number))