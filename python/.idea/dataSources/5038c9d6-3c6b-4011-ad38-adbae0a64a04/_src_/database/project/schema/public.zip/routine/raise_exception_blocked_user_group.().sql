CREATE FUNCTION raise_exception_blocked_user_group () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    IF (exists(
        SELECT * FROM group_blocked_users_table
        WHERE tel_number = NEW.tel_number AND group_id = NEW.group_id))
      THEN
      RAISE EXCEPTION 'This user is blocked!';
    END IF;
    RETURN NEW;
  END;
  
$$
