CREATE VIEW user_profile_view AS
SELECT user_table.tel_number,
    user_table.user_name,
    user_table.name,
    user_table.last_name,
    (now() - (user_table.last_seen)::timestamp with time zone) AS last_seen,
    user_profile_table.image_address AS profile_image
   FROM (user_table
     LEFT JOIN user_profile_table ON (((user_table.tel_number)::text = (user_profile_table.tel_number)::text)))
  WHERE ((user_profile_table.date)::timestamp without time zone >= ALL ( SELECT upt.date
           FROM user_profile_table upt
          WHERE ((user_table.tel_number)::text = (upt.tel_number)::text)))