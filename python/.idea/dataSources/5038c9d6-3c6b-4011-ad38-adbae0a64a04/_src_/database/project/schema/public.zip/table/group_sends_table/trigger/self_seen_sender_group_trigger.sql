CREATE TRIGGER self_seen_sender_group_trigger
AFTER INSERT ON group_sends_table
FOR EACH ROW EXECUTE PROCEDURE self_seen_sender_group()