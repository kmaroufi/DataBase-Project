CREATE VIEW channel_messages_view AS
SELECT channel_sends_table.channel_id,
    user_profile_view.tel_number,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.profile_image,
    channel_sends_table.creator_tel_number,
    channel_sends_table.message_id,
    message_table.message_text AS text,
    message_table.media_address,
    channel_sends_table.send_time
   FROM ((user_profile_view
     JOIN channel_sends_table USING (tel_number))
     JOIN message_table USING (creator_tel_number, message_id))