CREATE VIEW group_list_view AS
SELECT membership_table.tel_number,
    group_table.group_id,
    group_table.name,
    group_profile_table.image_address
   FROM ((membership_table
     JOIN group_table USING (group_id))
     LEFT JOIN group_profile_table ON (((group_table.group_id)::integer = (group_profile_table.group_id)::integer)))
  WHERE ((group_profile_table.date)::timestamp without time zone >= ALL ( SELECT gpt.date
           FROM group_profile_table gpt
          WHERE ((group_profile_table.group_id)::integer = (gpt.group_id)::integer)))