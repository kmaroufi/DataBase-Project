CREATE VIEW group_pin_view AS
SELECT group_pin_table.group_id,
    group_pin_table.tel_number,
    group_pin_table.creator_tel_number,
    group_pin_table.message_id,
    group_pin_table.send_time,
    message_table.message_text AS text,
    message_table.media_address
   FROM (group_pin_table
     JOIN message_table USING (creator_tel_number, message_id))