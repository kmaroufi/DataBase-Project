CREATE TRIGGER delete_channel_zero_member_trigger
AFTER UPDATE OF member_count
  ON channel_table
FOR EACH ROW WHEN (((new.member_count) :: BIGINT = 0)) EXECUTE PROCEDURE delete_channel_zero_member()