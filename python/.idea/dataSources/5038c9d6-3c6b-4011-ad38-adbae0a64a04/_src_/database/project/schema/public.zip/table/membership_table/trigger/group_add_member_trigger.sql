CREATE TRIGGER group_add_member_trigger
AFTER INSERT ON membership_table
FOR EACH ROW EXECUTE PROCEDURE inc_group_member_count()