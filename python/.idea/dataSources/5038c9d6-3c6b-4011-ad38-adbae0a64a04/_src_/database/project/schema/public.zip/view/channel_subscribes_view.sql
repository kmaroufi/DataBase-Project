CREATE VIEW channel_subscribes_view AS
SELECT subscribe_table.channel_id,
    subscribe_table.tel_number,
    user_profile_view.user_name,
    user_profile_view.name,
    user_profile_view.last_name,
    user_profile_view.last_seen,
    user_profile_view.profile_image,
    subscribe_table.is_admin
   FROM (subscribe_table
     JOIN user_profile_view USING (tel_number))