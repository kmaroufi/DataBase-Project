CREATE FUNCTION raise_exception_non_member_sender_group () RETURNS trigger
	LANGUAGE plpgsql
AS $$
 BEGIN
    IF (NOT exists(
        SELECT * FROM membership_table
        WHERE tel_number = NEW.tel_number AND group_id = NEW.group_id))
      THEN
      RAISE EXCEPTION 'This user is not member of group!';
    END IF;
    RETURN NEW;
  END;
  
$$
