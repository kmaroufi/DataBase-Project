CREATE VIEW group_profile_view AS
SELECT group_table.group_id,
    group_table.name,
    group_table.member_count,
    group_profile_table.image_address
   FROM (group_table
     LEFT JOIN group_profile_table ON (((group_table.group_id)::integer = (group_profile_table.group_id)::integer)))
  WHERE ((group_profile_table.date)::timestamp without time zone >= ALL ( SELECT gpt.date
           FROM group_profile_table gpt
          WHERE ((group_profile_table.group_id)::integer = (gpt.group_id)::integer)))