CREATE VIEW channel_profile_view AS
SELECT channel_table.channel_id,
    channel_table.name,
    channel_table.member_count,
    channel_profile_table.image_address
   FROM (channel_table
     LEFT JOIN channel_profile_table ON (((channel_table.channel_id)::text = (channel_profile_table.channel_id)::text)))
  WHERE ((channel_profile_table.date)::timestamp without time zone >= ALL ( SELECT cpt.date
           FROM channel_profile_table cpt
          WHERE ((channel_profile_table.channel_id)::text = (cpt.channel_id)::text)))